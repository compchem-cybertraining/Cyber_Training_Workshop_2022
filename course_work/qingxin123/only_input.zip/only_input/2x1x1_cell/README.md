
1.  Run eQE calculations 
     
    file path��only_input\2x1x1_cell\eQE_type_1
    
    module load eqe/0.2.0
    
    mpirun -np 6 fdepw.x -ni 1 -in pen  (around 14 minutes)

    

2.  Run eQE calculations 

    file path: only_input\2x1x1_cell\eQE_type_2
    
    module load eqe/0.2.0 
    (If you type this command early at type_1, you don't need to type again)
    
    mpirun -np 6 fdepw.x -ni 2 -in pen

3. Run eQE calculations 

   file path: only_input\2x1x1_cell\eQE_type_3
   
   sbatch submit.slm

4. Run Quantum Espresso calculations 
   
   file path: only_input\2x1x1_cell\QE_numb_4_type
   
   sbatch submit.slm
    



